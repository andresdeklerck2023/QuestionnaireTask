﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace Deklerck_Andres_WPFApplication_Questionnaire
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
