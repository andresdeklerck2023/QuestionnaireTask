﻿using System;
using ConsoleApplicationQuestionnaire;
using QuestionnaireLibrary;

namespace ConsoleApplicationQuestionnaire
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Create a sample question
            var question = new Question("What is the capital of France?");
            question.AddAnswer(new Answer("Berlin", false));
            question.AddAnswer(new Answer("Madrid", false));
            question.AddAnswer(new Answer("Paris", true));
            question.AddAnswer(new Answer("Rome", false));

            // Display the question and possible answers
            Console.WriteLine(question.Text);
            for (int i = 0; i < question.Answers.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {question.Answers[i].Text}");
            }

            // Get the user's answer
            Console.Write("Select the correct answer (1-4): ");
            int userAnswer;
            while (!int.TryParse(Console.ReadLine(), out userAnswer) || userAnswer < 1 || userAnswer > question.Answers.Count)
            {
                Console.Write("Invalid input. Please select a number between 1 and 4: ");
            }

            // Check if the answer is correct
            if (question.IsCorrect(question.Answers[userAnswer - 1]))
            {
                Console.WriteLine("Correct!");
            }
            else
            {
                Console.WriteLine("Incorrect. The correct answer is Paris.");
            }
        }
    }
}
