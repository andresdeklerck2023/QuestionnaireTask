﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using QuestionnaireLibrary;
using TriviaApiLibrary;

namespace Deklerck_Andres_WPFApplication_Questionnaire
{
    public partial class MainWindow : Window, IQuestionHandler
    {
        private TriviaMultipleChoiceQuestion currentQuestion;
        // Track the current question index
        private int currentQuestionIndex = 0;

        // Track the player's score
        private int playerScore = 0;

        //Difficulty
        //private string selectedDifficulty;

        //Class player's score
        public class PlayerScore
        {
            public string Username { get; set; }
            public int Score { get; set; }
        }

        public MainWindow()
        {
            InitializeComponent();
        }

      /*  private string GetSelectedDifficulty()
        {
            if (easyRadioButton.IsChecked == true)
            {
                return "easy";

            }
            else if (mediumRadioButton.IsChecked == true)
            {
                return "medium";

            }
            else if (hardRadioButton.IsChecked == true)
            {
                return "hard";

            }
            else
            {
                // Default to medium difficulty if none selected
                return "medium";
            }

        }*/


        public async void ProcessQuestion(TriviaMultipleChoiceQuestion question)
        {
            if (question != null)
            {
                currentQuestion = question;
                //Text for the user so they knows on what question they are, what category and what difficulty.
                questionTitleTextBlock.Text = $"Question {currentQuestionIndex + 1} of 10 - Category: {question.Category} - Difficulty: {question.Difficulty}";
                questionTextBlock.Text = question.Question.Text;

                var answers = question.IncorrectAnswers.ToList();
                answers.Add(question.CorrectAnswer);
                answers = answers.OrderBy(a => Guid.NewGuid()).ToList(); // Shuffle the answers

                option1RadioButton.Content = answers[0];
                option2RadioButton.Content = answers[1];
                option3RadioButton.Content = answers[2];
                option4RadioButton.Content = answers[3];

                feedbackTextBlock.Text = string.Empty;
            }
            else
            {
                MessageBox.Show("Failed to fetch a question. Please try again.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        //Fetch random questions from the API
        private async void FetchRandomQuestionButton_Click(object sender, RoutedEventArgs e)
        {
           // string difficulty = GetSelectedDifficulty();
            await TriviaApiRequester.RequestRandomQuestion(this);
           // await TriviaApiRequester.RequestRandomQuestion(this, difficulty);
        }

        //Function when clicked on Start game button
        private void StartGame_Click(object sender, RoutedEventArgs e)
        {
            string username = usernameTextBox.Text.Trim();

            if (string.IsNullOrEmpty(username))
            {
                //Please enter an username
                MessageBox.Show("Please enter your username.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            UsernameGrid.Visibility = Visibility.Collapsed;  
            QuestionGrid.Visibility = Visibility.Visible;

            // Reset player's score and current question index
            playerScore = 0;
            currentQuestionIndex = 0;

            //Fetch random question from the API
            FetchRandomQuestionButton_Click(sender, e);
        }

        //Function when clicked on the submit answer button
        private void SubmitAnswer_Click(object sender, RoutedEventArgs e)
        {
            // Get the selected answer
            string selectedAnswer = null;
            if (option1RadioButton.IsChecked == true) selectedAnswer = option1RadioButton.Content.ToString();
            if (option2RadioButton.IsChecked == true) selectedAnswer = option2RadioButton.Content.ToString();
            if (option3RadioButton.IsChecked == true) selectedAnswer = option3RadioButton.Content.ToString();
            if (option4RadioButton.IsChecked == true) selectedAnswer = option4RadioButton.Content.ToString();

            // Check if the selected answer is correct
            if (selectedAnswer != null)
            {
                if (selectedAnswer == currentQuestion.CorrectAnswer)
                {
                    //Answered correctly
                    playerScore++;
                    feedbackTextBlock.Text = "Correct!";
                    feedbackTextBlock.Foreground = new SolidColorBrush(Colors.Green);
                }
                else
                {
                    //Wrongly answered
                    feedbackTextBlock.Text = $"Wrong! The correct answer is: {currentQuestion.CorrectAnswer}.";
                    feedbackTextBlock.Foreground = new SolidColorBrush(Colors.Red);
                }

                // Reset answerbuttons
                option1RadioButton.IsChecked = false;
                option2RadioButton.IsChecked = false;
                option3RadioButton.IsChecked = false;
                option4RadioButton.IsChecked = false;

                currentQuestionIndex++;
                if (currentQuestionIndex < 10)
                {
                    // Delay between questions so it runs smoothly
                    var timer = new System.Windows.Threading.DispatcherTimer { Interval = TimeSpan.FromSeconds(2) };
                    timer.Tick += (s, args) =>
                    {
                        timer.Stop();
                        FetchRandomQuestionButton_Click(sender, e);
                    };
                    timer.Start();
                }
                else
                {
                    // Game Over
                    MessageBox.Show($"Game over! Your score is {playerScore} out of 10.", "Game Over", MessageBoxButton.OK, MessageBoxImage.Information);
                    DisplayLeaderboard();
                    QuestionGrid.Visibility = Visibility.Collapsed;
                    UsernameGrid.Visibility = Visibility.Visible;
                }
            }
            else
            {
                MessageBox.Show("Please select an answer.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void DisplayLeaderboard()
        {
            List<PlayerScore> leaderboard = new List<PlayerScore>
            {
                new PlayerScore { Username = usernameTextBox.Text.Trim(), Score = playerScore }
                // Add more player scores if needed...
            };

            leaderboardListView.ItemsSource = leaderboard.OrderByDescending(s => s.Score).ToList();
        }

        private void AboutPage_Click(object sender, RoutedEventArgs e)
        {
            // Switch to the about tab
            ((TabControl)UsernameGrid.Parent).SelectedIndex = 2;
        }

        //Clickable hyperlink to github repo
        private void Hyperlink_RequestNavigate(object sender, System.Windows.Navigation.RequestNavigateEventArgs e)
        {
            try
            {
                System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
                {
                    FileName = e.Uri.AbsoluteUri,
                    UseShellExecute = true
                });
                e.Handled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Unable to open link: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
