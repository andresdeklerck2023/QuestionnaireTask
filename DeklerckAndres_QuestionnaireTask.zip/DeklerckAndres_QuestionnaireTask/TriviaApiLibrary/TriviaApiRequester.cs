﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.Http;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace TriviaApiLibrary
{
    public class TriviaApiRequester
    {
        private static readonly HttpClient client = new HttpClient();

        private static TriviaMultipleChoiceQuestion ParseToQuestion(string question)
        {
            if (question == null) return null;

            TriviaMultipleChoiceQuestion result = null;
            try
            {
                result = JsonConvert.DeserializeObject<TriviaMultipleChoiceQuestion>(question);
            }
            catch (JsonSerializationException ex)
            {
                Trace.WriteLine(ex.Message);
            }

            return result;
        }

        public static async Task RequestRandomQuestion(IQuestionHandler handler)

        {
            try
            {
                string responseBody = await client.GetStringAsync($"https://the-trivia-api.com/v2/questions?type=choice&limit=1&difficulty=easy");
                Trace.WriteLine(responseBody);

                handler.ProcessQuestion(ParseToQuestion(
                        responseBody.Substring(1, responseBody.Length - 2)       
                    ));
            }
            catch (HttpRequestException e)
            {
                handler.ProcessQuestion(null);
            }
        }

    }
}
