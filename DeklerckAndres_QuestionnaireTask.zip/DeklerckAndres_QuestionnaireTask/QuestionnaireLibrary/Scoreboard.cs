﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuestionnaireLibrary
{
    public class Scoreboard
    {
        private List<(string player, int score)> scores;

        public Scoreboard()
        {
            scores = new List<(string player, int score)>();
        }

        public void AddPlayer(string player, int score)
        {
            scores.Add((player, score));
        }

        public void SortScoreboard()
        {
            scores = scores.OrderByDescending(s => s.score).ToList();
        }

        public List<(string player, int score)> GetTopScores()
        {
            return scores.Take(10).ToList();
        }
    }
}
