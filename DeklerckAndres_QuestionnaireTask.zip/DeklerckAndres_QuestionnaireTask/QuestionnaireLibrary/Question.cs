﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuestionnaireLibrary
{
    public class Question
    {
        public string Text { get; set; }
        public List<Answer> Answers { get; set; }

        public Question(string text)
        {
            Text = text;
            Answers = new List<Answer>();
        }

        public void AddAnswer(Answer answer)
        {
            Answers.Add(answer);
        }

        public bool IsCorrect(Answer answer)
        {
            return answer.IsCorrect;
        }
    }
}
