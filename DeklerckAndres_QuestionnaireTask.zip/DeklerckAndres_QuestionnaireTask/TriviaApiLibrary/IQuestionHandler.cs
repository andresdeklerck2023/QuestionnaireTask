﻿namespace TriviaApiLibrary
{
    public interface IQuestionHandler
    {
        void ProcessQuestion(TriviaMultipleChoiceQuestion question);
    }
}